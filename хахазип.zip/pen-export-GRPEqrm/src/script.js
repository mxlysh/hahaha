function makeItFunny() {
  var inputString = prompt("Введите строку:");
  var n = parseInt(prompt("Введите значение n:"));

  if (isNaN(n) || n <= 0) {
    alert("Ты чё наделал? Написано же значение введи а не буквы.");
    return;
  }
  var result = "";
  for (var i = 0; i < inputString.length; i++) {
    if ((i + 1) % n === 0) {
      result += inputString[i].toUpperCase();
    } else {
      result += inputString[i];
    }
  }
  alert("Вот твоя хахашка: " + result);
}
        var makeFunnyButton = document.getElementById("makeFunnyButton");
        makeFunnyButton.addEventListener("click", makeItFunny);